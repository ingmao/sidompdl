<?php

class SiteController extends Controller
{
	/**
	 * Declares class-based actions.
	 */
	public function actions()
	{
		return array(
			// captcha action renders the CAPTCHA image displayed on the contact page
			'captcha'=>array(
				'class'=>'CCaptchaAction',
				'backColor'=>0xFFFFFF,
			),
			// page action renders "static" pages stored under 'protected/views/site/pages'
			// They can be accessed via: index.php?r=site/page&view=FileName
			'page'=>array(
				'class'=>'CViewAction',
			),
		);
	}

	/**
	 * This is the default 'index' action that is invoked
	 * when an action is not explicitly requested by users.
	 */
	public function actionIndex()
	{
		// renders the view file 'protected/views/site/index.php'
		// using the default layout 'protected/views/layouts/main.php'
		$this->render('index');
	}

	/**
	 * This is the action to handle external exceptions.
	 */
	public function actionError()
	{
		if($error=Yii::app()->errorHandler->error)
		{
			if(Yii::app()->request->isAjaxRequest)
				echo $error['message'];
			else
				$this->render('error', $error);
		}
	}

	/**
	 * Displays the contact page
	 */
	public function actionContact()
	{
		$model=new ContactForm;
		if(isset($_POST['ContactForm']))
		{
			$model->attributes=$_POST['ContactForm'];
			if($model->validate())
			{
				$name='=?UTF-8?B?'.base64_encode($model->name).'?=';
				$subject='=?UTF-8?B?'.base64_encode($model->subject).'?=';
				$headers="From: $name <{$model->email}>\r\n".
					"Reply-To: {$model->email}\r\n".
					"MIME-Version: 1.0\r\n".
					"Content-Type: text/plain; charset=UTF-8";

				mail(Yii::app()->params['adminEmail'],$subject,$model->body,$headers);
				Yii::app()->user->setFlash('contact','Thank you for contacting us. We will respond to you as soon as possible.');
				$this->refresh();
			}
		}
		$this->render('contact',array('model'=>$model));
	}

	/**
	 * Displays the login page
	 */
	public function actionLogin()
	{
		$model=new LoginForm;

		// if it is ajax validation request
		if(isset($_POST['ajax']) && $_POST['ajax']==='login-form')
		{
			echo CActiveForm::validate($model);
			Yii::app()->end();
		}

		// collect user input data
		if(isset($_POST['LoginForm']))
		{
			$model->attributes=$_POST['LoginForm'];
			// validate user input and redirect to the previous page if valid
			if($model->validate() && $model->login())
				$this->redirect(Yii::app()->user->returnUrl);
		}
		// display the login form
		$this->render('login',array('model'=>$model));
	}

	/**
	 * Logs out the current user and redirect to homepage.
	 */
	public function actionLogout()
	{
		Yii::app()->user->logout();
		$this->redirect(Yii::app()->homeUrl);
	}
	
	public function actionserviciowsdl()
	{
		try {
		#INSTANCIAMOS EL MODELO BANCOS 
		 $model=new Bancos;	
		 #INSTACIAMOS LOS MODELOS Creartransaccion,payer,buyer,shipping y Resultadocreaciontransaccion
		 $mdRtr=new Resultadocreaciontransaccion;
		 $modtr=new Creartransaccion;
		 $modpy=new Payer;
		 $modby=new Buyer;
		 $modsh=new Shipping;
		 
		 #CREAMOS EL OBEJTO SOAP PARA EL CONSUMO DEL WDSL
		 $client = new SoapClient('https://test.placetopay.com/soap/pse/?wsdl');
		 #INICIALIZAMOS LAS VARIABLES A OPERAR
		 $mensaje="";
		 $seed=date('c');
		 $tranKey="024h1IlD";
		 $hashString =sha1($seed.$tranKey,false);
		 $params=array('login'=>'6dd490faf9cb87a9862245da41170ff2','tranKey'=>$hashString,'seed'=>$seed);
		 if($_POST){
			 $atributos=$_POST;
			 $atributos['auth']=$params;
			 $createTrasaccion=(array)$client->createTransaction($atributos);
			 $createTrasaccion=(array)$createTrasaccion['createTransactionResult'];
			 if($createTrasaccion['returnCode']=="SUCCESS"){
			 foreach($atributos['transaction'] as $key=>$val){
				 if($key!="payer" && $key!="buyer" && $key!="shipping"){
					 $tr[$key]=$val;
					 }else{
						 switch ($key) {
									case "payer":
										$payer=$val;
										break;
									case "buyer":
										$buyer=$val;
										break;
									case "shipping":
										$shipping=$val;
										break;
								}
						 }
				 
				 }
				
				$tr['fecha']=date('Y-m-d H:i:s'); 
				 
				 $modtr->attributes=$tr;
				
				 if($modtr->save()){
					 Yii::app()->db->getLastInsertID();
					$payer['py_tr_id']=Yii::app()->db->getLastInsertID(); 
					$buyer['by_tr_id']=Yii::app()->db->getLastInsertID(); 
					$shipping['sh_tr_id']=Yii::app()->db->getLastInsertID(); 
					$createTrasaccion['rsl_tr_id']=Yii::app()->db->getLastInsertID(); 
					$modpy->attributes=$payer;
				    $modby->attributes=$buyer;
				    $modsh->attributes=$shipping;
				    $mdRtr->attributes=$createTrasaccion;
					if($modpy->save() && $modby->save() && $modsh->save() && $mdRtr->save()){
						
						}else{
							echo CHtml::errorSummary($modpy);
							echo CHtml::errorSummary($modby);
							echo CHtml::errorSummary($modsh);
							echo CHtml::errorSummary($mdRtr);
							}
					 
					 
					 }else{
						 echo CHtml::errorSummary($modtr);
						 }
					#CONSULTAMOS SI EXISTE LISTA DE BANCOS EL DIA DE HOY
		 $mensaje=$createTrasaccion['responseReasonText'];				
		 $sql=$model->generico();	 
			  }
	      }else{ 
		 
		 #CONSULTAMOS SI EXISTE LISTA DE BANCOS EL DIA DE HOY
		 $sql=$model->generico();
		 #VALIDAMOS SI LA CONSULTA ES EXITOSA DE LO CONTRARIO SE CONSUME EL SERVICIO LISTA DE BANCOS
		 if(count($sql)){
		 }else{
			 #INCIALIZAMOS VARIABLE CON EL RESULTADO DEL CONSUMO LISTA DE BANCOS getBanlList		 
			 $result = (array)$client->getBankList(array('auth'=>$params));
			 #VALIDAMOS SI EL CONSUMO FUE EXITOSO
			 if(count($result)){
				 #RECOREMOS EL ARRAY INIICIALIZADO Y OBTENOS LAS LISTAS DE LOS BANCOS EN UN ARRAY
				 foreach($result['getBankListResult'] as $funcion=>$val){
					 foreach($val as $key=>$value){
						$value=(array)$value;
						$value['fecha']=date('Y-m-d'); 
						$listbank[]=$value;
						}
					 }
			// print_r($listbank);die;
			#TRUNCAMOS LA TABLA BANCOS
						 Yii::app()->db->createCommand('TRUNCATE TABLE bancos')->execute();
						 #RECORREMOS EL ARRAY DON LA LISTA DE LOS BANCOS Y LOS REGISTRAMOS.
						 #EN LA TABLA BANCOS
						 foreach($listbank as $key=>$val){
						#INSTANCIAMOS EL MODELO BANCOS PARA LOS REGISTROS 	 
						 $model=new Bancos;
						 #INICIALIZAMOS LO ATRIBUTOS DEL MODELO
						 $model->attributes=$val;
						 #VALIDAMOS SI EL REGISTRO FUE EXITOSO
						   if (!$model->save()) {
								echo '';
							} else {
								echo CHtml::errorSummary($model);
							}
						 }
					 }
					 #CONSULTAMOS LA LISTA DE LOS BANCOS ALMACENADOS
			 		$sql=$model->generico();
			 }
		}
		 } catch (SoapFault $fault) {
    		trigger_error("SOAP Fault: (faultcode: {$fault->faultcode}, faultstring: {$fault->faultstring})", E_USER_ERROR);
			
			}
		  #RENDERIZAMOS A LA VISTA QUE QUEREMOS VISUALIZAR Y PASAMOS EL PARAMETRO QUE QUEREMOS PROCESAR EN LA VISTA
		 $this->render('serviciowsdl',array('msg'=>$sql,'mensaje'=>$mensaje));
	}
}