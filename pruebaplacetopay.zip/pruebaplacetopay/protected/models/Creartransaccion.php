<?php

/**
 * This is the model class for table "creartransaccion".
 *
 * The followings are the available columns in table 'creartransaccion':
 * @property integer $tr_id
 * @property string $bankCode
 * @property string $bankInterface
 * @property string $returnURL
 * @property string $reference
 * @property string $description
 * @property string $language
 * @property string $currency
 * @property string $totalAmount
 * @property string $taxAmount
 * @property string $devolutionBase
 * @property string $tipAmount
 * @property string $ipAddress
 * @property string $userAgent
 * @property string $fecha
 *
 * The followings are the available model relations:
 * @property Buyer[] $buyers
 * @property Payer[] $payers
 * @property Resultadocreaciontransaccion[] $resultadocreaciontransaccions
 * @property Shipping[] $shippings
 */
class Creartransaccion extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'creartransaccion';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('bankCode, bankInterface, reference, description, language, currency, totalAmount, taxAmount, devolutionBase, tipAmount, ipAddress, userAgent, fecha', 'length', 'max'=>255),
			array('returnURL', 'length', 'max'=>500),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('tr_id, bankCode, bankInterface, returnURL, reference, description, language, currency, totalAmount, taxAmount, devolutionBase, tipAmount, ipAddress, userAgent, fecha', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'buyers' => array(self::HAS_MANY, 'Buyer', 'by_tr_id'),
			'payers' => array(self::HAS_MANY, 'Payer', 'py_tr_id'),
			'resultadocreaciontransaccions' => array(self::HAS_MANY, 'Resultadocreaciontransaccion', 'rsl_tr_id'),
			'shippings' => array(self::HAS_MANY, 'Shipping', 'sh_tr_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'tr_id' => 'Tr',
			'bankCode' => 'codigo banco',
			'bankInterface' => 'Bank Interface',
			'returnURL' => 'Return Url',
			'reference' => 'Reference',
			'description' => 'Description',
			'language' => 'Language',
			'currency' => 'Currency',
			'totalAmount' => 'Total Amount',
			'taxAmount' => 'Tax Amount',
			'devolutionBase' => 'Devolution Base',
			'tipAmount' => 'Tip Amount',
			'ipAddress' => 'Ip Address',
			'userAgent' => 'User Agent',
			'fecha' => 'Fecha',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('tr_id',$this->tr_id);
		$criteria->compare('bankCode',$this->bankCode,true);
		$criteria->compare('bankInterface',$this->bankInterface,true);
		$criteria->compare('returnURL',$this->returnURL,true);
		$criteria->compare('reference',$this->reference,true);
		$criteria->compare('description',$this->description,true);
		$criteria->compare('language',$this->language,true);
		$criteria->compare('currency',$this->currency,true);
		$criteria->compare('totalAmount',$this->totalAmount,true);
		$criteria->compare('taxAmount',$this->taxAmount,true);
		$criteria->compare('devolutionBase',$this->devolutionBase,true);
		$criteria->compare('tipAmount',$this->tipAmount,true);
		$criteria->compare('ipAddress',$this->ipAddress,true);
		$criteria->compare('userAgent',$this->userAgent,true);
		$criteria->compare('fecha',$this->fecha,true);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return Creartransaccion the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
}
