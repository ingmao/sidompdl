<?php

/**
 * This is the model class for table "shipping".
 *
 * The followings are the available columns in table 'shipping':
 * @property integer $sh_id
 * @property string $documentType
 * @property string $document
 * @property string $firstName
 * @property string $lastName
 * @property string $company
 * @property string $emailAddress
 * @property string $address
 * @property string $city
 * @property string $province
 * @property string $country
 * @property string $phone
 * @property string $mobile
 * @property integer $sh_tr_id
 *
 * The followings are the available model relations:
 * @property Creartransaccion $shTr
 */
class Shipping extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'shipping';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('sh_tr_id', 'numerical', 'integerOnly'=>true),
			array('documentType, document, firstName, lastName, company, emailAddress, address, city, province, country, phone, mobile', 'length', 'max'=>255),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('sh_id, documentType, document, firstName, lastName, company, emailAddress, address, city, province, country, phone, mobile, sh_tr_id', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'shTr' => array(self::BELONGS_TO, 'Creartransaccion', 'sh_tr_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'sh_id' => 'Sh',
			'documentType' => 'Document Type',
			'document' => 'Document',
			'firstName' => 'First Name',
			'lastName' => 'Last Name',
			'company' => 'Company',
			'emailAddress' => 'Email Address',
			'address' => 'Address',
			'city' => 'City',
			'province' => 'Province',
			'country' => 'Country',
			'phone' => 'Phone',
			'mobile' => 'Mobile',
			'sh_tr_id' => 'Sh Tr',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('sh_id',$this->sh_id);
		$criteria->compare('documentType',$this->documentType,true);
		$criteria->compare('document',$this->document,true);
		$criteria->compare('firstName',$this->firstName,true);
		$criteria->compare('lastName',$this->lastName,true);
		$criteria->compare('company',$this->company,true);
		$criteria->compare('emailAddress',$this->emailAddress,true);
		$criteria->compare('address',$this->address,true);
		$criteria->compare('city',$this->city,true);
		$criteria->compare('province',$this->province,true);
		$criteria->compare('country',$this->country,true);
		$criteria->compare('phone',$this->phone,true);
		$criteria->compare('mobile',$this->mobile,true);
		$criteria->compare('sh_tr_id',$this->sh_tr_id);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return Shipping the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
}
