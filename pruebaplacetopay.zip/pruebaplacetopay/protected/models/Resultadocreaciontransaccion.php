<?php

/**
 * This is the model class for table "resultadocreaciontransaccion".
 *
 * The followings are the available columns in table 'resultadocreaciontransaccion':
 * @property integer $rsl_id
 * @property integer $rsl_tr_id
 * @property string $returnCode
 * @property string $bankURL
 * @property string $trazabilityCode
 * @property string $transactionCycle
 * @property string $transactionID
 * @property string $sessionID
 * @property string $bankCurrency
 * @property string $bankFactor
 * @property string $responseCode
 * @property string $responseReasonCode
 * @property string $responseReasonText
 *
 * The followings are the available model relations:
 * @property Creartransaccion $rslTr
 */
class Resultadocreaciontransaccion extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'resultadocreaciontransaccion';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('rsl_tr_id', 'numerical', 'integerOnly'=>true),
			array('returnCode, bankURL, trazabilityCode, transactionCycle, transactionID, sessionID, bankCurrency, bankFactor, responseCode, responseReasonCode, responseReasonText', 'length', 'max'=>255),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('rsl_id, rsl_tr_id, returnCode, bankURL, trazabilityCode, transactionCycle, transactionID, sessionID, bankCurrency, bankFactor, responseCode, responseReasonCode, responseReasonText', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'rslTr' => array(self::BELONGS_TO, 'Creartransaccion', 'rsl_tr_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'rsl_id' => 'Rsl',
			'rsl_tr_id' => 'Rsl Tr',
			'returnCode' => 'Return Code',
			'bankURL' => 'Bank Url',
			'trazabilityCode' => 'Trazability Code',
			'transactionCycle' => 'Transaction Cycle',
			'transactionID' => 'Transaction',
			'sessionID' => 'Session',
			'bankCurrency' => 'Bank Currency',
			'bankFactor' => 'Bank Factor',
			'responseCode' => 'Response Code',
			'responseReasonCode' => 'Response Reason Code',
			'responseReasonText' => 'Response Reason Text',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('rsl_id',$this->rsl_id);
		$criteria->compare('rsl_tr_id',$this->rsl_tr_id);
		$criteria->compare('returnCode',$this->returnCode,true);
		$criteria->compare('bankURL',$this->bankURL,true);
		$criteria->compare('trazabilityCode',$this->trazabilityCode,true);
		$criteria->compare('transactionCycle',$this->transactionCycle,true);
		$criteria->compare('transactionID',$this->transactionID,true);
		$criteria->compare('sessionID',$this->sessionID,true);
		$criteria->compare('bankCurrency',$this->bankCurrency,true);
		$criteria->compare('bankFactor',$this->bankFactor,true);
		$criteria->compare('responseCode',$this->responseCode,true);
		$criteria->compare('responseReasonCode',$this->responseReasonCode,true);
		$criteria->compare('responseReasonText',$this->responseReasonText,true);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return Resultadocreaciontransaccion the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
}
