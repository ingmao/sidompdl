<?php

class metdosconsulta extends CFormModel
{

public function createTransaction($parametros){
	
	
	
	}

}
?>