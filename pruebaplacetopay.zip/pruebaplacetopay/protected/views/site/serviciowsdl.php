<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Transacciones</title>
</head>

<body>
<div>
<div><?php echo $mensaje;?></div>
  <form id="form1" name="form1" method="post" action="<?php echo Yii::app()->request->baseUrl;?>/index.php?r=site/serviciowsdl">
    <table width="100%" height="311" border="1" align="center">
      <tr>
        <th colspan="2" scope="col">Transacciones</th>
      </tr>
      <tr>
        <td width="123">Lista de bancos</td>
        <td width="41"><label for="listbank"></label>
          <select name="transaction[bankCode]" id="listbank" style="width:300px;">
          <option>Seleccione Banco</option>
            <?php if(isset($msg)){
			  foreach($msg as $key=>$val){ ?>
            <option value="<?php echo $val['bankCode'];?>"><?php echo $val['bankName'];?></option>
            <?php }}?>
          </select></td>
      </tr>
      <tr>
        <td>Tipo de interfaz del banco</td>
        <td><label for="bankInterface"></label>
          <select name="transaction[bankInterface]" id="bankInterface" style="width:300px;">
          	<option>Seleccione interfaz</option>
            <option value="0">Personas</option>
            <option value="1">Empresas</option>
            
          
        </select></td>
      </tr>
      <tr>
        <td>URL de retorno especificada para la entidad<br />
        financiera</td>
        <td><label for="returnURL"></label>
        <input type="text" name="transaction[returnURL]" id="returnURL"  value="<?php echo "http://localhost:81".Yii::app()->request->url;?>" readonly="readonly" style="width:100%;"/></td>
      </tr>
      <tr>
        <td>Referencia única de pago</td>
        <td><label for="reference"></label>
        <input type="text" name="transaction[reference]" id="reference" style="width:300px;"/></td>
      </tr>
      <tr>
        <td>Descripción del pago</td>
        <td><label for="description"></label>
        <textarea name="transaction[description]" id="description" cols="45" rows="5" style="width:300px;"></textarea></td>
      </tr>
      <tr>
        <td>Leguaje</td>
        <td><label for="language"></label>
          <select name="transaction[language]" id="language" style="width:300px;">
            <option>Seleccione idioma</option>
            <option value="ES">Español</option>
        </select></td>
      </tr>
      <tr>
        <td>Moneda</td>
        <td><label for="currency"></label>
          <select name="transaction[currency]" id="currency" style="width:300px;">
            <option>Seleccione moneda</option>
            <option value="COP">Colombia</option>
        </select></td>
      </tr>
      <tr>
        <td>Valor total a recaudar</td>
        <td><label for="totalAmount"></label>
        <input type="text" name="transaction[totalAmount]" id="totalAmount" style="width:300px;"/></td>
      </tr>
      <tr>
        <td>Discriminación del impuesto aplicado</td>
        <td><label for="taxAmount"></label>
        <input type="text" name="transaction[taxAmount]" id="taxAmount" style="width:300px;"/></td>
      </tr>
      <tr>
        <td>Base de devolución para el impuesto</td>
        <td><label for="devolutionBase"></label>
        <input type="text" name="transaction[devolutionBase]" id="devolutionBase" style="width:300px;"/></td>
      </tr>
      <tr>
        <td>Propina u otros valores exentos de impuesto<br />
          (tasa aeroportuaria) y que deben agregarse al<br />
        valor total a pagar</td>
        <td><label for="tipAmount"></label>
        <input type="text" name="transaction[tipAmount]" id="tipAmount" style="width:300px;"/></td>
      </tr>
      <tr>
        <th scope="col">Datos de Pagador</th>
        <th scope="col">Valores</th>
      </tr>
      <tr>
        <td>Documento</td>
        <td><label for="textfield"></label>
        <input name="transaction[payer][document]" type="text" id="textfield" style="width:300px;" /></td>
      </tr>
      <tr>
        <td>Tipo de documento</td>
        <td><label for="documentType"></label>
          <select name="transaction[payer][documentType]" id="documentType" style="width:300px;">
            <option>Seleccione tipo</option>
            <option value="CC">Cédula de ciudanía colombiana</option>
            <option value="CE">Cédula de extranjería</option>
            <option value="TI">Tarjeta de identidad</option>
            <option value="PPN">Pasaporte</option>
        </select></td>
      </tr>
      <tr>
        <td>Nombre</td>
        <td><input name="transaction[payer][firstName]" type="text" id="firstName" style="width:300px;" /></td>
      </tr>
      <tr>
        <td>Apellido</td>
        <td><input type="text" name="transaction[payer][lastName]" id="lastName" style="width:300px;" /></td>
      </tr>
      <tr>
        <td>Compañia</td>
        <td><input type="text" name="transaction[payer][company]" id="company" style="width:300px;" /></td>
      </tr>
      <tr>
        <td>Correo electronico</td>
        <td><input type="text" name="transaction[payer][emailAddress]" id="emailAddress" style="width:300px;" /></td>
      </tr>
      <tr>
        <td>Dirección</td>
        <td><input type="text" name="transaction[payer][address]" id="address" style="width:300px;" /></td>
      </tr>
      <tr>
        <td>Ciudad</td>
        <td><input type="text" name="transaction[payer][city]" id="city" style="width:300px;" /></td>
      </tr>
      <tr>
        <td>Provincia</td>
        <td><input type="text" name="transaction[payer][province]" id="province" style="width:300px;" /></td>
      </tr>
      <tr>
        <td>Codigo internacional</td>
        <td><input type="text" name="transaction[payer][country]" id="country" style="width:300px;" /></td>
      </tr>
      <tr>
        <td>Telefono</td>
        <td><input type="text" name="transaction[payer][phone]" id="phone" style="width:300px;" /></td>
      </tr>
      <tr>
        <td>Celular</td>
        <td><input type="text" name="transaction[payer][mobile]" id="mobile" style="width:300px;" /></td>
      </tr>
      <tr>
        <th scope="col">Datos de Comprador</th>
        <th scope="col">Valores</th>
      </tr>
      <tr>
        <td>Documento</td>
        <td><label for="documentC"></label>
          <input name="transaction[buyer][document]" type="text" id="documentC" style="width:300px;" /></td>
      </tr>
      <tr>
        <td>Tipo de documento</td>
        <td><label for="documentTypeC"></label>
          <select name="transaction[buyer][documentType]" id="documentTypeC" style="width:300px;">
          	<option>Seleccione tipo</option>
            <option value="CC">Cédula de ciudanía colombiana</option>
            <option value="CE">Cédula de extranjería</option>
            <option value="TI">Tarjeta de identidad</option>
            <option value="PPN">Pasaporte</option>
          </select></td>
      </tr>
      <tr>
        <td>Nombre</td>
        <td><input name="transaction[buyer][firstName]" type="text" id="firstNameC" style="width:300px;" /></td>
      </tr>
      <tr>
        <td>Apellido</td>
        <td><input type="text" name="transaction[buyer][lastName]" id="lastNameC" style="width:300px;" /></td>
      </tr>
      <tr>
        <td>Compañia</td>
        <td><input type="text" name="transaction[buyer][company]" id="companyC" style="width:300px;" /></td>
      </tr>
      <tr>
        <td>Correo electronico</td>
        <td><input type="text" name="transaction[buyer][emailAddress]" id="emailAddressC" style="width:300px;" /></td>
      </tr>
      <tr>
        <td>Dirección</td>
        <td><input type="text" name="transaction[buyer][address]" id="addressC" style="width:300px;" /></td>
      </tr>
      <tr>
        <td>Ciudad</td>
        <td><input type="text" name="transaction[buyer][city]" id="cityC" style="width:300px;" /></td>
      </tr>
      <tr>
        <td>Provincia</td>
        <td><input type="text" name="transaction[buyer][province]" id="provinceC" style="width:300px;" /></td>
      </tr>
      <tr>
        <td>Codigo internacional</td>
        <td><input type="text" name="transaction[buyer][country]" id="countryC" style="width:300px;" /></td>
      </tr>
      <tr>
        <td>Telefono</td>
        <td><input type="text" name="transaction[buyer][phone]" id="phoneC" style="width:300px;" /></td>
      </tr>
      <tr>
        <td>Celular</td>
        <td><input type="text" name="transaction[buyer][mobile]" id="mobileC" style="width:300px;" /></td>
      </tr>
      <tr>
        <th scope="col">Datos de Envio</th>
        <th scope="col">Valores</th>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td>Documento</td>
        <td><label for="documentE"></label>
          <input name="transaction[shipping][document]" type="text" id="documentE" style="width:300px;" /></td>
      </tr>
      <tr>
        <td>Tipo de documento</td>
        <td><label for="documentTypeE"></label>
          <select name="transaction[shipping][documentType]" id="documentTypeE" style="width:300px;">
          	<option>Seleccione tipo</option>
            <option value="CC">Cédula de ciudanía colombiana</option>
            <option value="CE">Cédula de extranjería</option>
            <option value="TI">Tarjeta de identidad</option>
            <option value="PPN">Pasaporte</option>
          </select></td>
      </tr>
      <tr>
        <td>Nombre</td>
        <td><input name="transaction[shipping][firstName]" type="text" id="firstNameE" style="width:300px;" /></td>
      </tr>
      <tr>
        <td>Apellido</td>
        <td><input type="text" name="transaction[shipping][lastName]" id="lastNameE" style="width:300px;" /></td>
      </tr>
      <tr>
        <td>Compañia</td>
        <td><input type="text" name="transaction[shipping][company]" id="companyE" style="width:300px;" /></td>
      </tr>
      <tr>
        <td>Correo electronico</td>
        <td><input type="text" name="transaction[shipping][emailAddress]" id="emailAddressE" style="width:300px;" /></td>
      </tr>
      <tr>
        <td>Dirección</td>
        <td><input type="text" name="transaction[shipping][address]" id="addressE" style="width:300px;" /></td>
      </tr>
      <tr>
        <td>Ciudad</td>
        <td><input type="text" name="transaction[shipping][city]" id="cityE" style="width:300px;" /></td>
      </tr>
      <tr>
        <td>Provincia</td>
        <td><input type="text" name="transaction[shipping][province]" id="provinceE" style="width:300px;" /></td>
      </tr>
      <tr>
        <td>Codigo internacional</td>
        <td><input type="text" name="transaction[shipping][country]" id="countryE" style="width:300px;" /></td>
      </tr>
      <tr>
        <td>Telefono</td>
        <td><input type="text" name="transaction[shipping][phone]" id="phoneE" style="width:300px;" /></td>
      </tr>
      <tr>
        <td>Celular</td>
        <td><input type="text" name="transaction[shipping][mobile]" id="mobileE" style="width:300px;" /></td>
      </tr>
      <tr>
        <td>Direccion IP</td>
        <td><label for="ipAddress"></label>
        <input type="text" name="transaction[ipAddress]" id="ipAddress" style="width:300px;" value="<?php echo Yii::app()->request->userHostAddress;?>" readonly="readonly"/></td>
      </tr>
      <tr>
        <td>Agenta de navegacion</td>
        <td><label for="userAgent"></label>
        <input type="text" name="transaction[userAgent]" id="userAgent" style="width:300px;"/></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      
      <tr>
        <td><button type="submit">Transaccion</button></td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
    </table>
  </form>
</div>
</body>
</html>