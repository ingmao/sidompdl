<?php

/**
 * UserIdentity represents the data needed to identity a user.
 * It contains the authentication method that checks if the provided
 * data can identity the user.
 */
class UserIdentity extends CUserIdentity
{
	// DECLARACION DE LAS VARIBALES.
	private $_id;
	/**
	 * Authenticates a user.
	 * The example implementation makes sure if the username and password
	 * are both 'demo'.
	 * In practical applications, this should be changed to authenticate
	 * against some persistent user identity storage (e.g. database).
	 * @return boolean whether authentication succeeds.
	 */
	public function authenticate()
	{
		//SE IMPORTA DEL MODULES AUTENTICACION EL MODELO USUARIOS
		//FORO:http://www.yiiframework.com/forum/index.php/topic/27155-como-usar-los-metodos-de-un-module-en-otro-controller/ 
		Yii::import('application.modules.autenticacion.models.Usuarios');
		// SE INSTANCIA EL MODELO USUARIOS Y SE CONSULTA EL NOMBRE DE USUARIO
 		$users=Usuarios::model()->find("LOWER(us_usuario)=?",array($this->username));
		// SE VALIDA EL USUARIO Y EL PASSWORD
		if(!isset($users->us_usuario))
			$this->errorCode=self::ERROR_USERNAME_INVALID;
		elseif($users->us_password!==md5($this->password))
			$this->errorCode=self::ERROR_PASSWORD_INVALID;
		else
		// SE SETEAN LOS PARAMETROS QUE SE QUIERAN UTILIZAR DENTRO DEL CODIGO
			$this->_id=$users->us_id;
			$this->errorCode=self::ERROR_NONE;
		return !$this->errorCode;
	}
}