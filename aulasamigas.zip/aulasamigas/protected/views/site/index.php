<?php
/* @var $this SiteController */
//Se inicializa la variable mensajes.
$mensaje="";
//se valida si esta autenticado.
if(Yii::app()->user->name!="Guest"){
	$mensaje="Bienvenido ".Yii::app()->user->name;
	}
//se le lleva el titulo del logo Aulas Amigas
$this->pageTitle=Yii::app()->name="Aulas Amigas";
echo $mensaje;
?>

