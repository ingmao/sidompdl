<?php
/* @var $this UsuariosController */
/* @var $data Usuarios */
?>

<div class="view">

	<b><?php echo CHtml::encode($data->getAttributeLabel('us_id')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->us_id), array('view', 'id'=>$data->us_id)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('us_nombre')); ?>:</b>
	<?php echo CHtml::encode($data->us_nombre); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('us_usuario')); ?>:</b>
	<?php echo CHtml::encode($data->us_usuario); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('us_password')); ?>:</b>
	<?php echo CHtml::encode($data->us_password); ?>
	<br />


</div>