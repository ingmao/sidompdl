<?php
/* @var $this UsuariosController */
/* @var $model Usuarios */

$this->breadcrumbs=array(
	'Usuarioses'=>array('index'),
	$model->us_id,
);
if(Yii::app()->user->name=="admin"){
	$menu=array(
	array('label'=>'Lista de  Usuarios', 'url'=>array('index')),
	array('label'=>'Registro de  Usuarios', 'url'=>array('create')),
	array('label'=>'Actulizacion de  Usuarios', 'url'=>array('update', 'id'=>$model->us_id)),
	array('label'=>'Eliminar Usuarios', 'url'=>'#', 'linkOptions'=>array('submit'=>array('delete','id'=>$model->us_id),'confirm'=>'Está seguro de que desea eliminar este registro?')),
	array('label'=>'Administracion de Usuarios', 'url'=>array('admin')),
);
	}else{
		$menu=array(
	array('label'=>'Lista de  Usuarios', 'url'=>array('index')),
	array('label'=>'Registro de  Usuarios', 'url'=>array('create')),
	array('label'=>'Actulizacion de  Usuarios', 'url'=>array('update', 'id'=>$model->us_id)),	
);
		}
$this->menu=$menu;
?>

<h1>Ver Usuarios #<?php echo $model->us_id; ?></h1>

<?php $this->widget('zii.widgets.CDetailView', array(
	'data'=>$model,
	'attributes'=>array(
		'us_id',
		'us_nombre',
		'us_usuario',
		'us_password',
	),
)); ?>
