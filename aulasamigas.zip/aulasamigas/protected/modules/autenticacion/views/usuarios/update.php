<?php
/* @var $this UsuariosController */
/* @var $model Usuarios */

$this->breadcrumbs=array(
	'Usuarioses'=>array('index'),
	$model->us_id=>array('view','id'=>$model->us_id),
	'Update',
);
if(Yii::app()->user->name=="admin"){
	$menu[]=array('label'=>'Lista de Usuarios', 'url'=>array('index'));
	$menu[]=array('label'=>'Registrar Usuarios', 'url'=>array('create'));
	$menu[]=array('label'=>'Ver Usuarios', 'url'=>array('view', 'id'=>$model->us_id));
	$menu[]=array('label'=>'Administracion de  Usuarios', 'url'=>array('admin'));
	}else{
		$menu[]=array('label'=>'Lista de Usuarios', 'url'=>array('index'));
		$menu[]=array('label'=>'Registrar Usuarios', 'url'=>array('create'));
		$menu[]=array('label'=>'Ver Usuarios', 'url'=>array('view', 'id'=>$model->us_id));
		}

$this->menu=$menu;
?>

<h1>Update Usuarios <?php echo $model->us_id; ?></h1>

<?php $this->renderPartial('_form', array('model'=>$model,'advertencia'=>$advertencia)); ?>