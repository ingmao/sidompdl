<?php
/* @var $this UsuariosController */
/* @var $dataProvider CActiveDataProvider */

$this->breadcrumbs=array(
	'Usuarioses',
);

if(Yii::app()->user->name=="admin"){
	$menu[]=array('label'=>'Registrar Usuarios', 'url'=>array('create'));
	$menu[]=array('label'=>'Administracion de Usuarios', 'url'=>array('admin'));
}else{
	$menu[]=array('label'=>'Registrar Usuarios', 'url'=>array('create'));
	}
$this->menu=$menu;
?>

<h1>Usuarios</h1>

<?php $this->widget('zii.widgets.CListView', array(
	'dataProvider'=>$dataProvider,
	'itemView'=>'_view',
)); ?>
