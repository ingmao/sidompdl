<?php
/* @var $this UsuariosController */
/* @var $model Usuarios */

$this->breadcrumbs=array(
	'Usuarioses'=>array('index'),
	'Create',
);
if(Yii::app()->user->name=="admin"){
	$menu[]=array('label'=>'Lista de usuarios', 'url'=>array('index'));
	$menu[]=array('label'=>'Administracion de Usuarios', 'url'=>array('admin'));
	}else{
		$menu[]=array('label'=>'Lista de usuarios', 'url'=>array('index'));
		}

$this->menu=$menu;
?>

<h1>Registro de Usuarios</h1>

<?php $this->renderPartial('_form', array('model'=>$model,'advertencia'=>$advertencia)); ?>